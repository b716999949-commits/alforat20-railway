'use strict';
(()=>{
 const el=document.querySelector('#v5-campaigns'),form=document.querySelector('#checkout-form');let interval;
 const esc5=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function clock(){document.querySelectorAll('[data-v5-end]').forEach(x=>{const ms=Date.parse(x.dataset.v5End)-Date.now();if(ms<=0){x.closest('.v5-campaign').hidden=true;return}const s=Math.floor(ms/1000),h=Math.floor(s/3600),m=Math.floor(s%3600/60);x.textContent=(h>23?Math.floor(h/24)+' يوم · ':'')+String(h%24).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0')})}
 async function init(){try{const r=await fetch('/api/v5/public',{cache:'no-store'});if(!r.ok)return;const d=await r.json(),c=d.config;
  const links=document.querySelector('.pro-store-links'),icons={info:'ⓘ',star:'★',phone:'☎',gift:'✦',help:'؟',shield:'✓'};for(const p of d.pages||[]){const a=document.createElement('a');a.href='/p/'+encodeURIComponent(p.slug);a.textContent=(icons[p.icon]||'')+' '+p.title;links.append(a)}
  const sections=c.sections.map(id=>document.getElementById(id)).filter(Boolean);if(sections.length){const anchor=document.createComment('v5 layout');sections[0].parentNode.insertBefore(anchor,sections[0]);let last=anchor;for(const section of sections){last.after(section);last=section}}
  const safe=s=>typeof s==='string'&&/^(?:https:\/\/|\/uploads\/|\/static\/assets\/)/.test(s);
  el.innerHTML=(c.banner_title||c.banner_text||c.banner_image?`<div class="v5-campaign">${safe(c.banner_image)?`<img loading="lazy" src="${esc5(c.banner_image)}" alt="">`:''}<div><h3>${esc5(c.banner_title)}</h3><p>${esc5(c.banner_text)}</p></div></div>`:'')+d.offers.map(o=>`<div class="v5-campaign"><div><small>عرض لفترة محدودة</small><h3>${esc5(o.title)}</h3><p>${esc5(o.description)}</p><b data-v5-end="${esc5(o.ends)}"></b>${o.product_id?` · <a href="/product/${encodeURIComponent(o.product_id)}">تفاصيل المنتج</a>`:''}</div></div>`).join('');clearInterval(interval);clock();interval=setInterval(clock,1000);
  const select=form.elements.delivery_region;select.innerHTML='<option value="">التوصيل بالاتفاق مع المتجر</option>'+d.delivery.map(x=>`<option value="${esc5(x.city)}">${esc5(x.city)} — ${esc5(Number(x.fee).toLocaleString('ar-YE'))} ر.ي</option>`).join('');
  const update=()=>{const item=d.delivery.find(x=>x.city===select.value);document.querySelector('#v5-delivery-note').textContent=item?'رسوم التوصيل: '+Number(item.fee).toLocaleString('ar-YE')+' ر.ي. اضغط احتساب الإجمالي.':'الرسوم النهائية تؤكد مع المتجر.';document.querySelector('#v4-quote-result').textContent='';renderCart()};select.onchange=update;form.addEventListener('reset',()=>setTimeout(update,0));
  document.querySelector('#v5-pay-note').textContent=c.payment_instructions;
 }catch{}}
 if(state.products.length)init();else window.addEventListener('furat:catalog-ready',init,{once:true});
 let install;const button=document.querySelector('#v5-install');window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();install=e;button.hidden=false});button.onclick=async()=>{if(!install)return;await install.prompt();install=null;button.hidden=true};window.addEventListener('appinstalled',()=>button.hidden=true);
})();

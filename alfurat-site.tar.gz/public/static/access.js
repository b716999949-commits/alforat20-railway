const mode = new URLSearchParams(location.search).get('mode') || 'login';
const owner = mode === 'owner';
const register = mode === 'register';
const form = document.querySelector('#access-form');
const email = form.elements.email;
const password = form.elements.password;
const submit = document.querySelector('#submit');
const switchMode = document.querySelector('#switch');
const status = document.querySelector('#status');
if (owner) {
  document.querySelector('#title').textContent = 'دخول مدير المتجر';
  document.querySelector('#email-label').hidden = true;
  email.required = false;
  switchMode.hidden = true;
} else if (register) {
  document.querySelector('#title').textContent = 'إنشاء حساب زبون';
  password.autocomplete = 'new-password';
  password.minLength = 12;
  password.placeholder = '12 حرفاً على الأقل';
  submit.textContent = 'إنشاء الحساب';
  switchMode.href = '/access';
  switchMode.textContent = 'لدي حساب بالفعل';
}
form.addEventListener('submit', async event => {
  event.preventDefault();
  submit.disabled = true;
  status.textContent = '';
  try {
    const action = owner ? 'owner' : register ? 'register' : 'login';
    const response = await fetch('/api/auth/'+action, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:email.value,password:password.value})
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || 'تعذّر تسجيل الدخول');
    location.replace(owner ? '/admin' : '/account');
  } catch (error) {
    status.textContent = error.message;
    submit.disabled = false;
  }
});

'use strict';
(()=>{
 const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const root=document.documentElement,body=document.body,mq=matchMedia('(prefers-reduced-motion: reduce)');
 const reduced=()=>mq.matches||body.classList.contains('v6-no-motion')||body.classList.contains('v4-reduce-motion');
 const refreshMotion=()=>root.classList.toggle('v62-reduce',reduced());
 refreshMotion();mq.addEventListener?.('change',refreshMotion);new MutationObserver(refreshMotion).observe(body,{attributes:true,attributeFilter:['class']});
 // Animate newly rendered cards only; no content is hidden if JS fails.
 const cards='.product-card,.category-card,.featured-card,.v6-reel,.v6-promo,.video-card,.facebook-card';
 const seen=new WeakSet();
 const enter=el=>{if(seen.has(el))return;seen.add(el);if(!reduced()){el.style.setProperty('--v62-delay',`${Math.min((Array.prototype.indexOf.call(el.parentElement?.children||[],el)%4)*32,96)}ms`);el.classList.add('v62-enter');el.addEventListener('animationend',()=>el.classList.remove('v62-enter'),{once:true});}};
 const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>{for(const e of entries){if(e.isIntersecting){observer.unobserve(e.target);enter(e.target);}}},{threshold:.08,rootMargin:'0px 0px 18px 0px'}):null;
 function watch(el){if(!el||el.nodeType!==1)return;const items=[...(el.matches(cards)?[el]:[]),...qa(cards,el)];for(const item of items){if(!seen.has(item)){if(observer)observer.observe(item);else enter(item);}}}
 watch(body);new MutationObserver(records=>{for(const m of records)for(const n of m.addedNodes)watch(n);}).observe(body,{childList:true,subtree:true});
 // Re-rendered management tabs retain their original handlers and permissions.
 for(const sel of ['#max-content','#pro-content','#pro-panel']){const el=q(sel);if(!el)continue;let raf=0;new MutationObserver(()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{if(reduced())return;el.getAnimations?.().filter(a=>a.id==='v62-panel').forEach(a=>a.cancel());const a=el.animate?.([{opacity:.5,translate:'0 7px'},{opacity:1,translate:'0 0'}],{duration:240,easing:'cubic-bezier(.2,.75,.25,1)'});if(a)a.id='v62-panel';});}).observe(el,{childList:true});}
 const nav=q('.mobile-bottom-nav'),header=q('.site-header');if(!nav||!header)return;
 const svg=(name)=>{const el=document.createElementNS('http://www.w3.org/2000/svg','svg');el.setAttribute('class','ui61-icon');el.setAttribute('viewBox','0 0 24 24');el.setAttribute('aria-hidden','true');const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','/static/assets/icons-v61.svg#'+name);el.append(use);return el;};
 const progress=document.createElement('span');progress.className='v62-scroll-progress';progress.setAttribute('aria-hidden','true');header.append(progress);
 const indicator=document.createElement('span');indicator.className='v62-nav-indicator';indicator.setAttribute('aria-hidden','true');nav.prepend(indicator);
 const jump=document.createElement('button');jump.type='button';jump.className='v62-jump';jump.setAttribute('aria-label','العودة إلى أعلى الصفحة');jump.append(svg('arrow-up'));body.append(jump);jump.onclick=()=>window.scrollTo({top:0,behavior:reduced()?'instant':'smooth'});
 const sectionIds=['top','categories','products','facebook','videos','contact'];let pending=false;
 function update(){pending=false;const height=header.getBoundingClientRect().height;root.style.setProperty('--v62-header-height',`${Math.ceil(height)}px`);const max=Math.max(1,document.scrollingElement.scrollHeight-innerHeight);progress.style.transform=`scaleX(${Math.min(1,Math.max(0,scrollY/max))})`;jump.classList.toggle('v62-show',scrollY>innerHeight*1.4&&!body.classList.contains('no-scroll'));
  let current='top';for(const id of sectionIds){const el=document.getElementById(id);if(el&&!el.hidden&&el.getClientRects().length&&el.getBoundingClientRect().top<=height+Math.min(160,innerHeight*.22))current=id;}
  const mobileTarget=({top:'top',categories:'products',products:'products',facebook:'videos',videos:'videos',contact:'videos'})[current];
  const active=q(`a[href="#${mobileTarget}"]`,nav);for(const a of qa('a',nav)){a.classList.toggle('selected',a===active);if(a===active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');}
  for(const a of qa('.v62-shortcuts a')){if(a.getAttribute('href')==='#'+current)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');}
  if(active&&nav.getClientRects().length){indicator.style.width=`${active.offsetWidth}px`;indicator.style.height=`${active.offsetHeight}px`;indicator.style.transform=`translate(${active.offsetLeft}px,${active.offsetTop}px)`;indicator.classList.add('ready');}else indicator.classList.remove('ready');
 }
 const schedule=()=>{if(!pending){pending=true;requestAnimationFrame(update);}};window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule,{passive:true});window.addEventListener('furat:catalog-ready',schedule);window.addEventListener('pageshow',schedule);if('ResizeObserver'in window){const ro=new ResizeObserver(schedule);ro.observe(header);ro.observe(nav);ro.observe(q('main'));}schedule();
 const menu=q('#mobile-menu'),toggle=q('#menu-toggle');if(menu&&toggle){toggle.setAttribute('aria-controls','mobile-menu');const sync=()=>toggle.setAttribute('aria-expanded',String(!menu.hidden));new MutationObserver(sync).observe(menu,{attributes:true,attributeFilter:['hidden']});sync();document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){menu.hidden=true;toggle.focus();}});document.addEventListener('click',e=>{if(!menu.hidden&&!menu.contains(e.target)&&!toggle.contains(e.target))menu.hidden=true;});}
 const count=q('#cart-count');if(count){let prev=count.textContent;new MutationObserver(()=>{const value=count.textContent;if(value===prev)return;const increased=Number(value)>Number(prev);prev=value;if(!increased||reduced())return;count.classList.remove('v62-pop');requestAnimationFrame(()=>{count.classList.add('v62-pop');});}).observe(count,{childList:true,characterData:true,subtree:true});count.addEventListener('animationend',()=>count.classList.remove('v62-pop'));}
 // Ensure the explicitly requested smooth scroll respects reduced motion too.
 for(const event of ['click'])document.addEventListener(event,e=>{const a=e.target.closest?.('a[href^="#"]');if(!a||a.hidden||e.defaultPrevented||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;const id=a.getAttribute('href').slice(1),dest=document.getElementById(id);if(!id||!dest||dest.hidden)return;if(id==='top'||reduced()){e.preventDefault();if(location.hash!=='#'+id)history.pushState(null,'','#'+id);if(id==='top')window.scrollTo({top:0,behavior:reduced()?'instant':'smooth'});else dest.scrollIntoView({behavior:'instant',block:'start'});}schedule();});
})();

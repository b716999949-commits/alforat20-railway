async function signOut() {
  const result = await fetch('/api/auth/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  if(result.ok) location.replace('/');
  else alert('تعذّر تسجيل الخروج. حاول مرة أخرى.');
}
document.addEventListener('click',event=>{
  if(event.target.closest('[data-signout]')) {
    event.preventDefault();
    signOut().catch(()=>alert('تعذّر الاتصال بالمتجر.'));
  }
});

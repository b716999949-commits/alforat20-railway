'use strict';(()=>{
 const q=s=>document.querySelector(s),search=q('#v63-search');if(!search)return;
 search.addEventListener('click',()=>q('#header-search').click());
 const image=q('#v6-hero-image'),art=q('.v63-hero-art');
 const sync=()=>{art.hidden=!image.hidden&&image.complete&&image.naturalWidth>0;};
 image.addEventListener('load',sync);image.addEventListener('error',()=>{image.hidden=true;art.hidden=false});new MutationObserver(sync).observe(image,{attributes:true,attributeFilter:['hidden','src']});sync();
})();

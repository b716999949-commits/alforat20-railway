import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { createReadStream, existsSync, mkdirSync, statSync, realpathSync, mkdtempSync, rmSync, chmodSync, renameSync, readdirSync, statfsSync, readFileSync } from 'node:fs';
import { dirname, resolve, join, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { tmpdir } from 'node:os';
import worker, {currentSession} from './worker.mjs';
import {initV5,createV5} from './v5.mjs';
import {initV6,createV6} from './v6.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const publicDir = realpathSync(join(root,'public'));
const railway = Boolean(process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID);
const volume = process.env.RAILWAY_VOLUME_MOUNT_PATH || (railway ? '/data' : join(root,'local-data'));
const dbPath = resolve(process.env.FURAT_DB_PATH || join(volume,'alfurat-v3.sqlite3'));
if (railway && (!existsSync(volume) || !dbPath.startsWith(resolve(volume)+sep))) throw Error('Mount persistent Railway volume at /data; keep FURAT_DB_PATH on this volume.');
if (railway && (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 20)) throw Error('Set ADMIN_PASSWORD to at least 20 characters in Railway Variables.');
mkdirSync(dirname(dbPath),{recursive:true,mode:0o700});
const existed = existsSync(dbPath);
const sqlite = new DatabaseSync(dbPath);
sqlite.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
// Preserve a consistent pre-upgrade copy once; never overwrite an existing backup.
if(existed && !sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='v4_design'").get()){
  const prior=join(dirname(dbPath),'alfurat-v3-before-v4.sqlite3');
  if(!existsSync(prior)){
    const tmp=prior+'.tmp'; rmSync(tmp,{force:true});
    try {sqlite.exec('VACUUM INTO '+"'"+tmp.replaceAll("'","''")+"'"); chmodSync(tmp,0o600); renameSync(tmp,prior);}
    catch(e){rmSync(tmp,{force:true});throw Error('Pre-upgrade backup failed; existing data was not migrated');}
  }
}

const normalize = value => value instanceof ArrayBuffer ? new Uint8Array(value) : typeof value==='boolean' ? Number(value) : value;
class Statement {
  constructor(sql,args=[]) { this.sql=sql; this.args=args; }
  bind(...args) { return new Statement(this.sql,args); }
  first() { return sqlite.prepare(this.sql).get(...this.args.map(normalize)) ?? null; }
  all() { return {results:sqlite.prepare(this.sql).all(...this.args.map(normalize)),success:true}; }
  run() { const result=sqlite.prepare(this.sql).run(...this.args.map(normalize)); return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}}; }
}
const DB={prepare:sql=>new Statement(sql),batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const results=statements.map(statement=>statement.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
// Initialize once before accepting traffic. SQLite executes the original worker seed transaction.
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.mp4':'video/mp4','.webmanifest':'application/manifest+json; charset=utf-8','.ico':'image/x-icon'};
const pages={'/':'index.html','/admin':'admin.html','/account':'account.html','/access':'access.html','/pro':'pro.html','/services':'services.html','/compare':'compare.html','/policies':'policies.html','/max':'max.html'};
const ASSETS={async fetch(req){
  if (!['GET','HEAD'].includes(req.method)) return new Response('Method not allowed',{status:405});
  let urlPath;try{urlPath=decodeURIComponent(new URL(req.url).pathname);}catch{return new Response('Bad request',{status:400});}
  if(urlPath.includes('\0')||urlPath.includes('\\')||urlPath.split('/').some(p=>p==='..'||p.startsWith('.'))) return new Response('Not found',{status:404});
  const relative=pages[urlPath] ?? urlPath.replace(/^\/+/, '');
  const file=resolve(publicDir,relative);
  if(!file.startsWith(publicDir+sep)||!existsSync(file)||!statSync(file).isFile()||!realpathSync(file).startsWith(publicDir+sep)) return new Response('Not found',{status:404});
  const size=statSync(file).size;
  const headers=new Headers({'Content-Type':types[extname(file)]||'application/octet-stream','Content-Length':String(size),'X-Content-Type-Options':'nosniff','Cache-Control':/\.(html|js|css|webmanifest)$/.test(file)?'no-cache':'public, max-age=86400','Accept-Ranges':'bytes'});
  let start=0,end=size-1,status=200;
  const range=req.headers.get('range');
  if(range && size>0){const m=range.match(/^bytes=(\d*)-(\d*)$/);if(!m||(!m[1]&&!m[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});if(!m[1]){const suffix=Number(m[2]);start=Math.max(0,size-suffix);}else{start=Number(m[1]);if(m[2])end=Math.min(size-1,Number(m[2]));}if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>end||start>=size)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});status=206;headers.set('Content-Range',`bytes ${start}-${end}/${size}`);headers.set('Content-Length',String(end-start+1));}
  return new Response(req.method==='HEAD'||size===0?null:Readable.toWeb(createReadStream(file,{start,end})),{status,headers});
}};
const env={DB,ASSETS,ADMIN_PASSWORD:process.env.ADMIN_PASSWORD};
const boot=await worker.fetch(new Request('http://localhost/api/catalog'),env);
if(!boot.ok)throw Error('Database initialization failed');
function backupAt(file){const tmp=file+'.tmp';rmSync(tmp,{force:true});try{sqlite.exec('VACUUM INTO '+"'"+tmp.replaceAll("'","''")+"'");chmodSync(tmp,0o600);renameSync(tmp,file)}catch(e){rmSync(tmp,{force:true});throw e}}
if(existed&&!sqlite.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='v5_config'").get()){
  const file=join(dirname(dbPath),'alfurat-before-v5.sqlite3');if(!existsSync(file))backupAt(file);
}
initV5(sqlite);
const v5=createV5(sqlite,env,currentSession);
if(existed&&!sqlite.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='v6_settings'").get()){
 const file=join(dirname(dbPath),'alfurat-before-v6.sqlite3');if(!existsSync(file))backupAt(file);
}
initV6(sqlite);const v6=createV6(sqlite,env,currentSession);
// One daily local backup, max 3, with conservative disk-space check. No external service.
function dailyBackup(){try{const dir=join(dirname(dbPath),'v5-backups');mkdirSync(dir,{recursive:true,mode:0o700});const file=join(dir,'daily-'+new Date().toISOString().slice(0,10)+'.sqlite3');if(existsSync(file))return;const space=statfsSync(dir),size=sqlite.prepare('PRAGMA page_count').get().page_count*sqlite.prepare('PRAGMA page_size').get().page_size;if(size>40*1024*1024||space.bavail*space.bsize<Math.max(50*1024*1024,size*2))return;backupAt(file);const old=readdirSync(dir).filter(x=>/^daily-\d{4}-\d{2}-\d{2}\.sqlite3$/.test(x)).sort();for(const n of old.slice(0,-3))rmSync(join(dir,n));}catch(e){console.warn('Daily backup skipped:',e.message)}}
const timer=setInterval(dailyBackup,3600000);timer.unref();dailyBackup();
const htmlEsc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pageTemplate=readFileSync(join(publicDir,'product.html'),'utf8');
const customTemplate=readFileSync(join(publicDir,'custom.html'),'utf8');
const publicOrigin=process.env.RAILWAY_PUBLIC_DOMAIN?'https://'+process.env.RAILWAY_PUBLIC_DOMAIN:'https://alfurat-mobile-v2-production.up.railway.app';

const hostFromEnv=process.env.RAILWAY_PUBLIC_DOMAIN;
const server=http.createServer(async (incoming,outgoing)=>{
  try {
    const host=incoming.headers.host||'localhost';
    if(!/^[A-Za-z0-9.\-]+(?::\d{1,5})?$/.test(host)) {outgoing.writeHead(400);outgoing.end('Bad request');return;}
    const scheme=railway?'https':'http';
    const url=new URL(incoming.url||'/',`${scheme}://${host}`);
    if(url.host!==host || url.protocol!==scheme+':'){outgoing.writeHead(400);outgoing.end('Bad request');return;}
    if(url.pathname==='/health'){sqlite.prepare('SELECT 1').get();outgoing.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});outgoing.end('{"status":"ok"}');return;}
    const headers=new Headers();
    for(const [k,v] of Object.entries(incoming.headers))if(v!==undefined&&!['connection','transfer-encoding','upgrade','expect','cf-connecting-ip','oai-authenticated-user-id','oai-authenticated-user-email'].includes(k))headers.set(k,Array.isArray(v)?v.join(', '):v);
    // Railway edge supplies the forwarding chain; use its rightmost entry, not client-controlled leftmost values.
    const forwarded=String(incoming.headers['x-forwarded-for']||'').split(',').map(s=>s.trim()).filter(Boolean);
    headers.set('CF-Connecting-IP',railway&&forwarded.length?forwarded.at(-1):incoming.socket.remoteAddress||'local');
    const method=incoming.method||'GET';
    if(method==='GET'||method==='HEAD'){
      if(url.pathname==='/robots.txt'){outgoing.writeHead(200,{'Content-Type':'text/plain; charset=utf-8'});outgoing.end('User-agent: *\nDisallow: /admin\nDisallow: /pro\nDisallow: /max\nDisallow: /account\nDisallow: /api/\nSitemap: '+publicOrigin+'/sitemap.xml\n');return;}
      if(url.pathname==='/sitemap.xml'){const urls=['/','/policies',...sqlite.prepare('SELECT slug FROM v5_pages WHERE published=1').all().map(p=>'/p/'+encodeURIComponent(p.slug)),...sqlite.prepare('SELECT id FROM products').all().map(p=>'/product/'+encodeURIComponent(p.id))];outgoing.writeHead(200,{'Content-Type':'application/xml; charset=utf-8'});outgoing.end('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls.map(p=>'<url><loc>'+htmlEsc(publicOrigin+p)+'</loc></url>').join('')+'</urlset>');return;}
      const custom=url.pathname.match(/^\/p\/([a-z0-9][a-z0-9-]{1,59})$/);if(custom){const p=sqlite.prepare('SELECT title,content FROM v5_pages WHERE slug=? AND published=1').get(custom[1]);if(!p){outgoing.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});outgoing.end('الصفحة غير موجودة');return}const content=customTemplate.replaceAll('%%TITLE%%',htmlEsc(p.title)).replaceAll('%%DESCRIPTION%%',htmlEsc(p.content.slice(0,180))).replaceAll('%%CANONICAL%%',htmlEsc(publicOrigin+url.pathname)).replace('%%CONTENT%%',htmlEsc(p.content));outgoing.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});outgoing.end(method==='HEAD'?'':content);return;}
      const match=url.pathname.match(/^\/product\/([A-Za-z0-9_-]{1,100})$/);if(match){const p=sqlite.prepare('SELECT id,name,description,price,image_url FROM products WHERE id=?').get(match[1]);if(!p){outgoing.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});outgoing.end('المنتج غير موجود');return;}const content=pageTemplate.replaceAll('%%TITLE%%',htmlEsc(p.name)).replaceAll('%%DESCRIPTION%%',htmlEsc(p.description.slice(0,220))).replaceAll('%%CANONICAL%%',htmlEsc(publicOrigin+url.pathname));outgoing.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});outgoing.end(method==='HEAD'?'':content);return;}
    }
    let body;
    if(!['GET','HEAD'].includes(method)){
      const MAX=6_200_000;let length=0;const chunks=[];
      if(Number(incoming.headers['content-length'])>MAX){outgoing.writeHead(413);outgoing.end('Payload too large');return;}
      for await (const chunk of incoming){length+=chunk.length;if(length>MAX){outgoing.writeHead(413);outgoing.end('Payload too large');return;}chunks.push(chunk);}body=Buffer.concat(chunks);
    }
    if(url.pathname==='/api/admin/backup' && method==='GET'){
      const auth=await worker.fetch(new Request(new URL('/api/admin/me',url),{headers}),env);
      if(!auth.ok){outgoing.writeHead(auth.status,{'Content-Type':'application/json','Cache-Control':'no-store'});outgoing.end(await auth.text());return;}
      if(headers.get('sec-fetch-site')==='cross-site'){outgoing.writeHead(403);outgoing.end();return;}
      const temp=mkdtempSync(join(tmpdir(),'furat-backup-')); const file=join(temp,'store.sqlite3');
      try{sqlite.exec('VACUUM INTO '+"'"+file.replaceAll("'","''")+"'");chmodSync(file,0o600);
        const stream=createReadStream(file); const clean=()=>rmSync(temp,{recursive:true,force:true});
        outgoing.on('close',()=>{stream.destroy();clean();});stream.on('error',()=>{clean();outgoing.destroy();});
        outgoing.writeHead(200,{'Content-Type':'application/octet-stream','Content-Disposition':'attachment; filename="alfurat-backup-'+new Date().toISOString().slice(0,10)+'.sqlite3"','Content-Length':statSync(file).size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});stream.pipe(outgoing);return;
      }catch(e){rmSync(temp,{recursive:true,force:true});throw e;}
    }
    const request=new Request(url,{method,headers,body});
    const response=url.pathname.startsWith('/api/v6/')?await v6.handle(request):url.pathname.startsWith('/api/v5/')?await v5.handle(request):await worker.fetch(request,env);
    if(response.ok&&url.pathname.startsWith('/api/admin/')&&!['GET','HEAD'].includes(method)){try{const session=await currentSession(request,env);if(session?.role==='admin')v5.audit('owner',method,url.pathname.slice(0,200))}catch{}}

    const resultHeaders=Object.fromEntries(response.headers);resultHeaders['x-content-type-options']='nosniff';
    if(response.headers.getSetCookie().length)resultHeaders['set-cookie']=response.headers.getSetCookie();
    if(url.pathname.startsWith('/api/')) resultHeaders['cache-control']='no-store';
    outgoing.writeHead(response.status,resultHeaders);
    if(!response.body||method==='HEAD'){outgoing.end();return;}
    Readable.fromWeb(response.body).on('error',()=>outgoing.destroy()).pipe(outgoing);
  }catch(error){console.error('Request error:',error.message);if(!outgoing.headersSent)outgoing.writeHead(500,{'Content-Type':'application/json','Cache-Control':'no-store'});outgoing.end(JSON.stringify({detail:'تعذر إكمال الطلب'}));}
});
server.requestTimeout=30000;
server.listen(Number(process.env.PORT||8080),'0.0.0.0',()=>console.log('Alfurat store is ready'));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{sqlite.close();process.exit(0);}));
